package com.example.babylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void animalFunction(View view) {
        Intent inti= new Intent(this,animalFunction.class);
        startActivity(inti);
    }
    public void fruitFunction(View view) {
        Intent inti= new Intent(this,fruitFunction.class);
        startActivity(inti);
    }
    public void birdFunction(View view) {
        Intent inti= new Intent(this,Birdfunction.class);
        startActivity(inti);
    }
    public void colorFunction(View view) {
        Intent inti= new Intent(this,colorfunction.class);
        startActivity(inti);
    }

    public void FungameFunction2(View view) {
        Intent inti= new Intent(this,quize.class);
        startActivity(inti);
    }



}

package com.example.babylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }



    public void nextFunction(View view) {
        Intent myintent = new Intent(this,MainActivity3.class);
        startActivity(myintent);
    }


    public void ABCFunction(View view) {
        Intent inti= new Intent(this,abcpage.class);
        startActivity(inti);
    }

    public void numFunction(View view) {
        Intent inti= new Intent(this,num.class);
        startActivity(inti);
    }

    public void FlowerFunction(View view) {
        Intent inti= new Intent(this,flower.class);
        startActivity(inti);
    }

    public void ShapeFunction(View view) {
        Intent inti= new Intent(this,shape.class);
        startActivity(inti);
    }



}
package com.example.babylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    String[] age;
    private TextView textView;
    private Button button;
    private Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn1Id);
        age = getResources().getStringArray(R.array.Kids_Age);
        spinner = findViewById(R.id.spinnerID);
        textView = findViewById(R.id.TextviewId);
        button = findViewById(R.id.buttonId);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.samplelayout,R.id.textSampleId,age);
        spinner.setAdapter(adapter);
    }


    public void ButtonmainFunction(View view) {
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);


    }


    public void SubmitBtnFunction(View view) {
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);
    }


    public void submitbtn(View view) {
        String value = spinner.getSelectedItem().toString();
        textView.setText("Hey kids of age "+value);
    }
}
package com.example.babylearn;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class colorfunction extends AppCompatActivity {
    Fragment myFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colorfunction);
    }

    public void changeFragment(View view) {
        if (view == findViewById(R.id.buttonA)) {
            myFragment = new FragmentA();
        } else if (view == findViewById(R.id.buttonB)) {
            myFragment = new FragmentB();
        } else if (view == findViewById(R.id.buttonC)) {
            myFragment = new FragementC();
        } else {
            myFragment = new FragmentD();
        }
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction ft = FM.beginTransaction();
        ft.replace(R.id.myFragmetnId, myFragment);
        ft.commit();
    }
}
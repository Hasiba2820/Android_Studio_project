package com.example.babylearn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class quize extends AppCompatActivity {
    RadioGroup radioGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quize);

        radioGroup=findViewById(R.id.radioGrpId);
    }
    public void SubmitBtnFunction(View view) {
        if(radioGroup.getCheckedRadioButtonId()==R.id.btn4){
            Toast.makeText(this, "Right Answer", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Wrong Answer", Toast.LENGTH_SHORT).show();
        }
    }

    public void FinalPage(View view) {
        Intent inti= new Intent(this,Finalpage.class);
        startActivity(inti);
    }
}